import { useState, useEffect } from "react";

export function StatsBar() {
  const [delivery, setDelivery] = useState(40);
  const [bugs, setBugs] = useState(30);

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate slight variations in real-time stats
      setDelivery(prev => Math.min(50, Math.max(35, prev + (Math.random() - 0.5) * 2)));
      setBugs(prev => Math.min(35, Math.max(25, prev + (Math.random() - 0.5) * 2)));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center justify-center gap-6 text-sm">
      <div className="flex items-center gap-2">
        <span className="text-amber-700">Faster Delivery:</span>
        <span className="font-bold text-amber-900 font-mono">
          {delivery.toFixed(0)}%
        </span>
      </div>
      <div className="w-px h-4 bg-amber-300" />
      <div className="flex items-center gap-2">
        <span className="text-amber-700">Fewer Bugs:</span>
        <span className="font-bold text-amber-900 font-mono">
          {bugs.toFixed(0)}%
        </span>
      </div>
    </div>
  );
}