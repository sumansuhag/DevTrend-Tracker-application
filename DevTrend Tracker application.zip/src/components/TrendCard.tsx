import { useState, useEffect } from "react";
import { Trend } from "../utils/trends";

interface TrendCardProps {
  trend: Trend;
}

export function TrendCard({ trend }: TrendCardProps) {
  const Icon = trend.icon;
  const [progress, setProgress] = useState(85);
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    // Simulate real-time updates every 5-10 seconds
    const interval = setInterval(() => {
      setIsUpdating(true);
      const newProgress = Math.floor(Math.random() * 15) + 80; // 80-95%
      setProgress(newProgress);
      
      setTimeout(() => setIsUpdating(false), 500);
    }, Math.random() * 5000 + 5000);

    return () => clearInterval(interval);
  }, []);

  const circumference = 2 * Math.PI * 20;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className="group relative bg-white border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-md hover:scale-[1.02] transition-all duration-200 focus-within:ring-2 focus-within:ring-blue-500">
      {/* Live indicator */}
      <div className="absolute top-3 right-3 flex items-center gap-1">
        <div className={`w-1.5 h-1.5 rounded-full ${isUpdating ? 'bg-green-500 animate-pulse' : 'bg-slate-300'}`} />
      </div>

      {/* Tooltip */}
      <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap pointer-events-none z-10">
        {trend.whyItMatters}
        <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-slate-800 rotate-45" />
      </div>

      {/* Header with icon and progress ring */}
      <div className="flex items-start justify-between mb-4">
        <div className="bg-blue-50 p-3 rounded-lg">
          <Icon className="w-6 h-6 text-blue-600" />
        </div>
        
        {/* Circular progress ring with animation */}
        <div className="relative w-12 h-12">
          <svg className="w-12 h-12 -rotate-90" viewBox="0 0 48 48">
            <circle
              cx="24"
              cy="24"
              r="20"
              fill="none"
              stroke="#e5e7eb"
              strokeWidth="4"
            />
            <circle
              cx="24"
              cy="24"
              r="20"
              fill="none"
              stroke="#2563eb"
              strokeWidth="4"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              strokeLinecap="round"
              className={`transition-all duration-500 ${isUpdating ? 'animate-pulse' : ''}`}
            />
          </svg>
          <span className="absolute inset-0 flex items-center justify-center text-xs font-semibold text-blue-600">
            {progress}%
          </span>
        </div>
      </div>

      {/* Content */}
      <h3 className="text-base font-semibold text-slate-900 mb-2">
        {trend.title}
      </h3>
      <p className="text-sm text-slate-600 mb-3">
        {trend.description}
      </p>
      <p className="text-xs text-slate-500 font-medium">
        {trend.benefit}
      </p>
    </div>
  );
}