import { useState } from "react";
import { trends } from "./utils/trends";
import { TrendCard } from "./components/TrendCard";
import { SourcesModal } from "./components/SourcesModal";
import { LiveClock } from "./components/LiveClock";
import { StatsBar } from "./components/StatsBar";
import { Button } from "./components/ui/button";

function App() {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header with live clock */}
      <header className="border-b border-gray-200 py-3 px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">DT</span>
            </div>
            <span className="font-semibold text-slate-900">DevTrend Tracker</span>
          </div>
          <LiveClock />
        </div>
      </header>

      {/* Summary Insight Banner with live stats */}
      <div className="bg-amber-50 border-b border-amber-200">
        <div className="py-4 px-6">
          <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-amber-900 text-center sm:text-left font-medium">
              Teams adopting AI, DevOps, and modern standards see improved outcomes
            </p>
            <StatsBar />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto w-full p-6">
        <section className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <h1 className="text-2xl font-bold text-slate-900">
              Technology Trends
            </h1>
            <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-medium rounded-full">
              Live
            </span>
          </div>
          <p className="text-slate-600">
            Real-time insights into technologies shaping software development
          </p>
        </section>

        {/* Trend Cards Grid */}
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {trends.map((trend) => (
            <TrendCard key={trend.title} trend={trend} />
          ))}
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 py-6 px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span>Based on 2024 industry research • Updated in real-time</span>
          </div>
          <Button
            variant="ghost"
            onClick={() => setModalOpen(true)}
            className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 font-medium"
          >
            View Sources
          </Button>
        </div>
      </footer>

      {/* Sources Modal */}
      <SourcesModal open={modalOpen} onOpenChange={setModalOpen} />
    </div>
  );
}

export default App;