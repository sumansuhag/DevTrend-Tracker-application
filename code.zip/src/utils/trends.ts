import { Brain, Cog, Lock, Leaf } from "../lib/icons";

export interface Trend {
  title: string;
  description: string;
  benefit: string;
  whyItMatters: string;
  icon: React.ComponentType<{ className?: string }>;
}

export const trends: Trend[] = [
  {
    title: "AI & ML",
    description: "Customizes user experiences and automates testing & deployment",
    benefit: "Enhances software operations through intelligent automation",
    whyItMatters: "Reduces manual effort by 60% while improving code quality",
    icon: Brain,
  },
  {
    title: "DevOps",
    description: "Bridges development and operations for continuous delivery",
    benefit: "Accelerates release cycles with automated pipelines",
    whyItMatters: "Enables 10x faster deployment frequency",
    icon: Cog,
  },
  {
    title: "Blockchain",
    description: "Decentralized ledger technology for secure transactions",
    benefit: "Provides immutable audit trails and smart contracts",
    whyItMatters: "Eliminates single points of failure in critical systems",
    icon: Lock,
  },
  {
    title: "Agile/DevSecOps",
    description: "Integrates security into every stage of development",
    benefit: "Shifts security left to catch vulnerabilities early",
    whyItMatters: "Reduces security remediation costs by 75%",
    icon: Leaf,
  },
];