import { X } from "../lib/icons";
import { Button } from "../components/ui/button";

interface SourcesModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SourcesModal({ open, onOpenChange }: SourcesModalProps) {
  const sources = [
    "Gartner: DevOps Adoption 2024",
    "IEEE: AI in Software Development Lifecycle",
    "State of DevOps Report 2023",
    "Forrester: Blockchain in Enterprise Systems",
    "MIT Technology Review: Security-First Development",
  ];

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50"
        onClick={() => onOpenChange(false)}
      />
      
      {/* Modal Content */}
      <div className="relative bg-white rounded-xl shadow-lg max-w-md w-full mx-4 p-6 animate-in fade-in zoom-in duration-200">
        {/* Close Button */}
        <button
          onClick={() => onOpenChange(false)}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <h2 className="text-lg font-semibold text-slate-900 mb-4 pr-8">
          Research Sources
        </h2>
        
        {/* Sources List */}
        <div className="space-y-3">
          {sources.map((source, index) => (
            <div
              key={index}
              className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg"
            >
              <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0" />
              <span className="text-sm text-slate-700">{source}</span>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-6 flex justify-end">
          <Button
            onClick={() => onOpenChange(false)}
            className="bg-slate-900 hover:bg-slate-800 text-white"
          >
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}